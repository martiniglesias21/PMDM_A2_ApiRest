package com.example.a2_conexionapirest.model

class SeriesResponse : ArrayList<Series>()