package com.example.a2_conexionapirest.model

data class Series(
    val channel: String,
    val dates: String,
    val image: String,
    val rating: Double,
    val title: String
)